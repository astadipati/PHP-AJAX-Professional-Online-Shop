/****************************************************
  Main Javascript Function
  Hope - Smart, Clean, Responsive Dashboard Template
  Rubi Jihantoro
*****************************************************/

/**********************************
  Couple - Rubi Jihantoro
***********************************/
!function () {

  "use strict";

  var Menu = function (el, op) {
  	this.play('menu', el, op);
    this.forclose(el,op);
  }

  Menu.prototype = 
  {

  	constructor: Menu

    , forclose: function (el,op) {
        this.op = this.getOptions(op)
        var oC   = this.op.callbacks.onClose;
        function onClose(){
          oC();
        }
        window.onclick = function(event) {
          if (event.target.matches('[couple-data]') == false 
          &&  event.target.matches('[couple-id] > .icon') == false){
              $(".dropdown[couple-data]").removeClass('active');
              onClose();
            }
        }
    }
    , callBacks: function(w,el,op){
        this.op  = this.getOptions(op)
        var cb   = this.op.callbacks;
    }
  	, play: function (type, el, op) {
        this.type = type
        this.$el = $(el)
        this.op = this.getOptions(op)
        this.enabled = true
        type = this.op.type

        var oO   = this.op.callbacks.onOpen
        ,   oV   = this.op.callbacks.onVisible
        ,   oC   = this.op.callbacks.onClose;
        function getCallbacks(w){
          switch(w) {
              case 0: // o.o
                  oO();
                  break;
              case 1: // o.v
                  oV();
                  break;
              case 2: // o.c
                  oC();
                  break;
          }
        }

        $(el).each(function (){
          
          var id     = $(this).attr("couple-id")
          ,   source = $("[couple-id='"+id+"'] > ul").attr("couple-data");

          switch(type) {
              case 'click':
                  $(this).on({
                      click: function(){
                          $(".dropdown[couple-data!='"+id+"']").removeClass('active');
                            getCallbacks(2);

                        getCallbacks(0);
                          $(".dropdown[couple-data='"+id+"']").addClass('active');
                        getCallbacks(1);
                      }
                  });
                  break;
              case 'hover':
                  $(this).on({
                      mouseenter: function(){
                          $(".dropdown[couple-data!='"+id+"']").removeClass('active');
                            getCallbacks(2);

                        getCallbacks(0);
                          $(".dropdown[couple-data='"+id+"']").addClass('active');
                        getCallbacks(1);
                      }

                  });
                  break;
          }
        });

  	  }
    , getOptions: function (op) {
      op = $.extend({}, $.fn[this.type].defaults, op, this.$el.data())

      return op
    }

  }

$.fn.menu = function ( option ) {
    return this.each(function () {
      var $this = $(this)
        , data = $this.data('menu')
        , op = typeof option == 'object' && option;
     
      if (!data) $this.data('menu', (data = new Menu(this, op)))
      if (typeof option == 'string') data[option]()
    })
}

  $.fn.menu.Constructor = Menu

 $.fn.menu.defaults = {
    type: "image",
    acton : "hover",
    identity: ""
  }


}(window.jQuery);

$('.item').menu({
  type: "click",
  showfor: "topmenu",
  callbacks: {
    onOpen: function(){
      console.log('Jalan');
    },
    onVisible: function () {
      console.log('Aku Terlihat');
    },
    onClose: function () {
      console.log('Selamat Tinggal');
    }
  }
});


/************************************
  Malihu Scroolbar - Main Bar
*************************************/
$(".main-content").mCustomScrollbar({
  theme:"minimal-dark",
  keyboard:{
    enable:true,
    scrollType:"stepless",
    scrollAmount:"auto"
  }
});
$(".scrolled.list").mCustomScrollbar({
  theme:"minimal-dark",
  keyboard:{
    enable:true,
    scrollType:"stepless",
    scrollAmount:"auto"
  }
});
$(".chat.list").mCustomScrollbar({
  theme:"minimal-bright",
  keyboard:{
    enable:true,
    scrollType:"stepless",
    scrollAmount:"auto"
  }
});
/**********************************
  Realtime Chat
***********************************/
$(function () {

    var data = [],
        totalPoints = 300;

    function getRandomData() {

        if (data.length > 0)
            data = data.slice(1);

        while (data.length < totalPoints) {

            var prev = data.length > 0 ? data[data.length - 1] : 50,
                y = prev + Math.random() * 10 - 5;

            if (y < 0) {
                y = 0;
            } else if (y > 100) {
                y = 100;
            }

            data.push(y);
        }

        var res = [];
        for (var i = 0; i < data.length; ++i) {
            res.push([i, data[i]])
        }

        return res;
    }

    var updateInterval = 30;
    $("#updateInterval").val(updateInterval).change(function () {
        var v = $(this).val();
        if (v && !isNaN(+v)) {
            updateInterval = +v;
            if (updateInterval < 1) {
                updateInterval = 1;
            } else if (updateInterval > 2000) {
                updateInterval = 2000;
            }
            $(this).val("" + updateInterval);
        }
    });


    var plot = $.plot("#placeholderRT", [getRandomData()], {
        series: {
            shadowSize: 0
        },
        yaxis: {
            min: 0,
            max: 100
        },
        xaxis: {
            show: false
        }
    });

    function update() {

        plot.setData([getRandomData()]);

        plot.draw();
        setTimeout(update, updateInterval);
    }

    update();

});
/*************************************
  Cards - Rubi Jihantoro
**************************************/
$(function () {
  $('.cards').each(function () {
    var p = $(this).attr('class')
    ,   w = $(p+' > .card')
    ,   s = p+' > .card'
    ,   l = $(p+' > .card').length
    ,   m = '"'+p+'"';

    for (var i = l - 1; i >= 0; i--) {

      if($(m).attr('top-height') == undefined
      || typeof $(m).attr('top-height') == 'undefined'
      || $(m).attr('top-height') == 'undefined'
      || !$(m).attr('top-height'))
        $(m).attr('top-height', 2);
      
      if($(s+':nth-child('+i+')').height() > $(m).attr('top-height')-1+1)
        $(m).attr('top-height', $(s+':nth-child('+i+')').height());

      $(s).height($(m).attr('top-height'));

      alert(i);
    }
  })
});
/*******************************************
  Auto Active Sidebar Menu - Rubi Jihantoro
********************************************/
$(function () {
  var a = $('.sidebar > .menu').attr('active-menu');
  $('.sidebar > .menu > [menu-id="'+a+'"]').addClass('active');
  $('.sidebar > .menu > [menu-id!="'+a+'"]').removeClass('active');
});
